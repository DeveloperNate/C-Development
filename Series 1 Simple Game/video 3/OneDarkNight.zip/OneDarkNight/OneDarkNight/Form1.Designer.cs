﻿namespace OneDarkNight
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.characterButton = new System.Windows.Forms.Button();
            this.mainImage = new System.Windows.Forms.PictureBox();
            this.mainTitle = new System.Windows.Forms.Label();
            this.characterName = new System.Windows.Forms.TextBox();
            this.characterRace = new System.Windows.Forms.ComboBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.mainImage)).BeginInit();
            this.SuspendLayout();
            // 
            // characterButton
            // 
            this.characterButton.BackColor = System.Drawing.SystemColors.ControlDark;
            this.characterButton.Font = new System.Drawing.Font("Matura MT Script Capitals", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.characterButton.Location = new System.Drawing.Point(29, 274);
            this.characterButton.Name = "characterButton";
            this.characterButton.Size = new System.Drawing.Size(278, 38);
            this.characterButton.TabIndex = 0;
            this.characterButton.Text = "Create Your Character";
            this.characterButton.UseVisualStyleBackColor = false;
            this.characterButton.Click += new System.EventHandler(this.characterButton_Click);
            // 
            // mainImage
            // 
            this.mainImage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mainImage.BackgroundImage")));
            this.mainImage.Location = new System.Drawing.Point(358, 12);
            this.mainImage.Name = "mainImage";
            this.mainImage.Size = new System.Drawing.Size(430, 344);
            this.mainImage.TabIndex = 1;
            this.mainImage.TabStop = false;
            // 
            // mainTitle
            // 
            this.mainTitle.AutoSize = true;
            this.mainTitle.Font = new System.Drawing.Font("Matura MT Script Capitals", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainTitle.Location = new System.Drawing.Point(6, 24);
            this.mainTitle.Name = "mainTitle";
            this.mainTitle.Size = new System.Drawing.Size(346, 50);
            this.mainTitle.TabIndex = 2;
            this.mainTitle.Text = "One Dark Night";
            // 
            // characterName
            // 
            this.characterName.Location = new System.Drawing.Point(169, 120);
            this.characterName.Name = "characterName";
            this.characterName.Size = new System.Drawing.Size(160, 20);
            this.characterName.TabIndex = 3;
            // 
            // characterRace
            // 
            this.characterRace.FormattingEnabled = true;
            this.characterRace.Items.AddRange(new object[] {
            "Elf",
            "Dwarf",
            "Human",
            "Wizard "});
            this.characterRace.Location = new System.Drawing.Point(185, 207);
            this.characterRace.Name = "characterRace";
            this.characterRace.Size = new System.Drawing.Size(144, 21);
            this.characterRace.TabIndex = 4;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Matura MT Script Capitals", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(11, 120);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(152, 20);
            this.nameLabel.TabIndex = 5;
            this.nameLabel.Text = "Enter Your Name : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Matura MT Script Capitals", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 208);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "Pick Your Character : ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 391);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.characterRace);
            this.Controls.Add(this.characterName);
            this.Controls.Add(this.mainTitle);
            this.Controls.Add(this.mainImage);
            this.Controls.Add(this.characterButton);
            this.Name = "Form1";
            this.Text = "Main Menu";
            ((System.ComponentModel.ISupportInitialize)(this.mainImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button characterButton;
        private System.Windows.Forms.PictureBox mainImage;
        private System.Windows.Forms.Label mainTitle;
        private System.Windows.Forms.TextBox characterName;
        private System.Windows.Forms.ComboBox characterRace;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label label1;
    }
}

